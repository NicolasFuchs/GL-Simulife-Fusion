package move;

import creature.Creature;

public class MoveRook extends Move {
    public MoveRook(Creature[][] game, Creature c) {
      super(game, c);
  }
}
